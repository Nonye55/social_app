 $(document).ready(function () {
     $('#modal-btn').click(function () {
         console.log('working');
         $('.ui.modal')
          .modal('show')
        ;

     })


  });